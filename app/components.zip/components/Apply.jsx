export default function Apply() {
  return (
    <section className="flex justify-center px-4 md:px-10 pt-6 relative">
      <div className="relative flex flex-col md:pb-10 lg:flex-row items-center justify-between w-full max-w-7xl bg-green-600 rounded-[32px] overflow-hidden pt-10 lg:pt-16 text-white">
        
        <div className="px-6 md:px-12 lg:px-[60px]">
          {/* Текст + форма */}
          <div className="z-10 max-w-xl">
            <h1 className="text-2xl sm:text-3xl lg:text-[32px] font-bold leading-relaxed mb-6">
              Подайте заявку, и мы пригласим<br />
              вас присоединиться к нашей<br />
              команде.
            </h1>

            <input
              type="text"
              placeholder="Введите номер телефона"
              className="w-full md:w-2/3 px-4 py-3 rounded-lg border-2 border-white text-white mb-4 text-base outline-none bg-transparent placeholder-white"
            />

            <button
              className="w-full md:w-2/3 bg-white text-green-600 font-bold text-base py-3 rounded-lg hover:bg-gray-100 transition"
            >
              Оставить заявку
            </button>
          </div>
        </div>

      </div>
    </section>
  )
}
